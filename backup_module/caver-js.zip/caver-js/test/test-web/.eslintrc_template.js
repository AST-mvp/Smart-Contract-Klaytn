module.exports = {
    extends: ['react-app', 'react-app/jest'],
}
