/* global window */
/* eslint no-undef: "error" */

window.Caver = require('./index.js')
