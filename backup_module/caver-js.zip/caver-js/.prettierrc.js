module.exports = {
    semi: false,
    printWidth: 140,
    singleQuote: true,
    arrowParens: 'avoid',
    bracketSpacing: true,
    tabWidth: 4,
    trailingComma: 'es5',
}
